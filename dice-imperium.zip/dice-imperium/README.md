# Dice Imperium

A board game for the browser that mixes **Monopoly** and **Risk**: march around a Monopoly style board loop, but instead of buying territories, you invade them with Risk style dice battles.

Pass and play for 2 to 4 players on one screen. The whole game is a single `index.html` file with no dependencies, no build step, and no assets. Music and sound effects are generated live with the Web Audio API.

## Play

Open `index.html` in any modern browser. That's it.

To play it online, enable GitHub Pages for this repository (Settings, Pages, deploy from branch) and the game will be served at your Pages URL.

## Rules

* Roll two dice and march clockwise around the world.
* **Free territory:** garrison it with troops from your reserve to claim it.
* **Enemy territory:** invade! Attacker rolls up to 3 dice, defender up to 2. Highest dice are compared pairwise and ties favor the defender. Battle until the territory falls, your force is destroyed, or you retreat.
* **Your own territory:** reinforce the garrison.
* Pass **Command HQ** to collect 5 fresh troops, plus a bonus for every continent you fully control.
* Corners: **Quarantine** skips your next turn, **War Chest** pays a die roll of troops, **Airlift** flies you to any territory on the map.
* Doubles roll again. Three doubles in a row sends you straight to Quarantine.
* **Win** by controlling 3 complete continents, or the entire map.

## Credits

Built with Claude Code.
